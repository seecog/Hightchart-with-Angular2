import { AbcDirective } from './abc.directive';

describe('AbcDirective', () => {
  it('should create an instance', () => {
    const directive = new AbcDirective();
    expect(directive).toBeTruthy();
  });
});
