import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {CalendarModule} from 'primeng/calendar';
import {AccordionModule} from 'primeng/accordion';     //accordion and accordion tab
import {MenuItem} from 'primeng/api';   

import {CheckboxModule} from 'primeng/checkbox';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './parent/child/child.component';
import { ProductsComponent } from './parent/products/products.component';
import { ProductComponent } from './parent/products/product/product.component';
import { ManagerComponent } from './parent/products/manager/manager.component';
import { EmpComponent } from './parent/products/manager/emp/emp.component';
import { Obse1Component } from './obse1/obse1.component';
import { AbcDirective } from './abc.directive';
import { DefDirective } from './def.directive';              //api
@NgModule({
  declarations: [
    AppComponent,
    ParentComponent,
    ChildComponent,
    ProductsComponent,
    ProductComponent,
    ManagerComponent,
    EmpComponent,
    Obse1Component,
    AbcDirective,
    DefDirective
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AccordionModule,
    CalendarModule,
    FormsModule,
    CheckboxModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
