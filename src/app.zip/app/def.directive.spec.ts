import { DefDirective } from './def.directive';

describe('DefDirective', () => {
  it('should create an instance', () => {
    const directive = new DefDirective();
    expect(directive).toBeTruthy();
  });
});
